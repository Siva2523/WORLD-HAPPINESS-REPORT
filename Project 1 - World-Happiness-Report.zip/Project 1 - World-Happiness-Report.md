```python
import numpy as np 
import pandas as pd

```


```python
df = pd.read_csv("https://raw.githubusercontent.com/dsrscientist/DSData/master/happiness_score_dataset.csv")
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>Region</th>
      <th>Happiness Rank</th>
      <th>Happiness Score</th>
      <th>Standard Error</th>
      <th>Economy (GDP per Capita)</th>
      <th>Family</th>
      <th>Health (Life Expectancy)</th>
      <th>Freedom</th>
      <th>Trust (Government Corruption)</th>
      <th>Generosity</th>
      <th>Dystopia Residual</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Switzerland</td>
      <td>Western Europe</td>
      <td>1</td>
      <td>7.587</td>
      <td>0.03411</td>
      <td>1.39651</td>
      <td>1.34951</td>
      <td>0.94143</td>
      <td>0.66557</td>
      <td>0.41978</td>
      <td>0.29678</td>
      <td>2.51738</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Iceland</td>
      <td>Western Europe</td>
      <td>2</td>
      <td>7.561</td>
      <td>0.04884</td>
      <td>1.30232</td>
      <td>1.40223</td>
      <td>0.94784</td>
      <td>0.62877</td>
      <td>0.14145</td>
      <td>0.43630</td>
      <td>2.70201</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Denmark</td>
      <td>Western Europe</td>
      <td>3</td>
      <td>7.527</td>
      <td>0.03328</td>
      <td>1.32548</td>
      <td>1.36058</td>
      <td>0.87464</td>
      <td>0.64938</td>
      <td>0.48357</td>
      <td>0.34139</td>
      <td>2.49204</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Norway</td>
      <td>Western Europe</td>
      <td>4</td>
      <td>7.522</td>
      <td>0.03880</td>
      <td>1.45900</td>
      <td>1.33095</td>
      <td>0.88521</td>
      <td>0.66973</td>
      <td>0.36503</td>
      <td>0.34699</td>
      <td>2.46531</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Canada</td>
      <td>North America</td>
      <td>5</td>
      <td>7.427</td>
      <td>0.03553</td>
      <td>1.32629</td>
      <td>1.32261</td>
      <td>0.90563</td>
      <td>0.63297</td>
      <td>0.32957</td>
      <td>0.45811</td>
      <td>2.45176</td>
    </tr>
  </tbody>
</table>
</div>




```python
!pip install bubbly
```

    Requirement already satisfied: bubbly in c:\programdata\anaconda3\lib\site-packages (1.0.2)
    Requirement already satisfied: pandas in c:\programdata\anaconda3\lib\site-packages (from bubbly) (1.2.4)
    Requirement already satisfied: plotly in c:\programdata\anaconda3\lib\site-packages (from bubbly) (5.5.0)
    Requirement already satisfied: python-dateutil>=2.7.3 in c:\programdata\anaconda3\lib\site-packages (from pandas->bubbly) (2.8.1)
    Requirement already satisfied: numpy>=1.16.5 in c:\programdata\anaconda3\lib\site-packages (from pandas->bubbly) (1.20.1)
    Requirement already satisfied: pytz>=2017.3 in c:\programdata\anaconda3\lib\site-packages (from pandas->bubbly) (2021.1)
    Requirement already satisfied: six>=1.5 in c:\programdata\anaconda3\lib\site-packages (from python-dateutil>=2.7.3->pandas->bubbly) (1.15.0)
    Requirement already satisfied: tenacity>=6.2.0 in c:\programdata\anaconda3\lib\site-packages (from plotly->bubbly) (8.0.1)
    


```python
import matplotlib.pyplot as plt
import seaborn as sns
plt.style.use('fivethirtyeight')


import plotly.offline as py
from plotly.offline import init_notebook_mode, iplot
import plotly.graph_objs as go
init_notebook_mode(connected = True)
from bubbly.bubbly import bubbleplot

import os
```


<script type="text/javascript">
window.PlotlyConfig = {MathJaxConfig: 'local'};
if (window.MathJax) {MathJax.Hub.Config({SVG: {font: "STIX-Web"}});}
if (typeof require !== 'undefined') {
require.undef("plotly");
requirejs.config({
    paths: {
        'plotly': ['https://cdn.plot.ly/plotly-2.8.3.min']
    }
});
require(['plotly'], function(Plotly) {
    window._Plotly = Plotly;
});
}
</script>




```python
df.isnull().sum()
```




    Country                          0
    Region                           0
    Happiness Rank                   0
    Happiness Score                  0
    Standard Error                   0
    Economy (GDP per Capita)         0
    Family                           0
    Health (Life Expectancy)         0
    Freedom                          0
    Trust (Government Corruption)    0
    Generosity                       0
    Dystopia Residual                0
    dtype: int64




```python
plt.rcParams['figure.figsize'] = (20, 15)
sns.heatmap(df.corr(), cmap = 'copper', annot = True)

plt.show()
```


    
![png](output_6_0.png)
    


#### In the above Heat Map we can see that Happiness Score is very highly correlated with Economy, Health, and Family Satisfaction and somewhat related with Freedom also but has very low relation with Trust in Government in average case.

## Correlations for Western Europe


```python
plt.rcParams['figure.figsize'] = (20, 15)
d = df.loc[lambda df: df['Region'] == 'Western Europe']
sns.heatmap(d.corr(), cmap = 'Wistia', annot = True)

plt.show()
```


    
![png](output_9_0.png)
    


####   The Heat Map particularly for Europe has one more thing to add apart from Family Satisfaction, Freedom, Economy, Generosity, It is also highly correlated with Trust in Government.

The European Region is the Happiest Region so far.

## Correlations for Eastern Asia


```python
plt.rcParams['figure.figsize'] = (20, 15)
d = df.loc[lambda df: df['Region'] == 'Eastern Asia']
sns.heatmap(d.corr(), cmap = 'Greys', annot = True)

plt.show()
```


    
![png](output_12_0.png)
    


#### Here, The situation gets worsened as the Correlation is negative for many important factors such as Economy, Health, Trust in Government which makes the situation very critical. It has Positive correlations only with Freedom, Generosity and Famlily Satisfaction.

## North America


```python
plt.rcParams['figure.figsize'] = (20, 15)
d = df.loc[lambda df : df['Region'] == 'North America']
sns.heatmap(d.corr(), cmap = 'pink', annot = True)

plt.show()
```


    
![png](output_15_0.png)
    


##### Everything is highly correlated to the Happiness in America. Amongst so many countries of the world. Being a very large country also America is still able to keep their people happy. America stands at position number 10 amongst the Happiness Rankings for the World.

## Middle East and Northern Africa


```python
plt.rcParams['figure.figsize'] = (20, 15)
d = df.loc[lambda df: df['Region'] == 'Middle East and Northern Africa']

sns.heatmap(d.corr(), cmap = 'rainbow', annot = True)

plt.show()
```


    
![png](output_18_0.png)
    


##### The correlations are quite goood with almost all the important factors being highly correlated with Happiness. Family Satisfaction is the most important factor as it is the most important factor for happiness n this region.

## Sub-Saharan Africa


```python
plt.rcParams['figure.figsize'] = (20, 15)
d = df.loc[lambda df: df['Region'] == 'Sub-Saharan Africa']
sns.heatmap(d.corr(), cmap = 'Blues', annot = True)

plt.show()
```


    
![png](output_21_0.png)
    


###### The Situations are very bad for Sub-Saharan Region as it is the unhappiest region in the world. The correlations with Happiness Score are very low for features such as Generosity, Family Satisfaction, Freedom etc. Almost all of the features are having less than 0.5 correlation which is very bad.

## Bubble Charts


```python
import warnings
warnings.filterwarnings('ignore')

figure = bubbleplot(dataset = df, x_column = 'Happiness Score', y_column = 'Generosity', 
    bubble_column = 'Country', size_column = 'Economy (GDP per Capita)', color_column = 'Region', 
    x_title = "Happiness Score", y_title = "Generosity", title = 'Happiness vs Generosity vs Economy',
    x_logscale = False, scale_bubble = 1, height = 650)

py.iplot(figure, config={'scrollzoom': True})
```


<div>                            <div id="a0689f03-02a9-4f09-8752-8cee6962ddab" class="plotly-graph-div" style="height:650px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("a0689f03-02a9-4f09-8752-8cee6962ddab")) {                    Plotly.newPlot(                        "a0689f03-02a9-4f09-8752-8cee6962ddab",                        [{"marker":{"size":[1.39651,1.30232,1.32548,1.459,1.29025,1.32944,1.33171,1.33723,1.56391,1.33596,1.30782,1.26637,1.32792,1.27778,1.23011,1.2074,1.25114,1.20806,1.20813,1.15991,1.15406],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Western Europe","text":["Switzerland","Iceland","Denmark","Norway","Finland","Netherlands","Sweden","Austria","Luxembourg","Ireland","Belgium","United Kingdom","Germany","France","Spain","Malta","Italy","North Cyprus","Cyprus","Portugal","Greece"],"x":[7.587,7.561,7.527,7.522,7.406,7.378,7.364,7.2,6.946,6.94,6.937,6.867,6.75,6.575,6.329,6.302,5.948,5.695,5.689,5.102,4.857],"y":[0.29678,0.4363,0.34139,0.34699,0.23351,0.4761,0.36262,0.33088,0.28034,0.45901,0.2225,0.51912,0.28214,0.12332,0.18227,0.51752,0.22823,0.26169,0.30638,0.13719,0.0],"type":"scatter"},{"marker":{"size":[1.32629,1.39451],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"North America","text":["Canada","United States"],"x":[7.427,7.119],"y":[0.45811,0.40105],"type":"scatter"},{"marker":{"size":[1.25018,1.33358],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Australia and New Zealand","text":["New Zealand","Australia"],"x":[7.286,7.284],"y":[0.47501,0.43562],"type":"scatter"},{"marker":{"size":[1.22857,1.42727,1.36011,1.69042,1.39541,1.55422,1.32376,1.13145,0.93929,1.06098,0.90198,0.73479,1.02564,0.88113,0.59867,1.0088,0.98549,0.8818,0.54649,0.6632],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Middle East and Northern Africa","text":["Israel","United Arab Emirates","Oman","Qatar","Saudi Arabia","Kuwait","Bahrain","Libya","Algeria","Turkey","Jordan","Morocco","Lebanon","Tunisia","Palestinian Territories","Iran","Iraq","Egypt","Yemen","Syria"],"x":[7.278,6.901,6.853,6.611,6.411,6.295,5.96,5.754,5.605,5.332,5.192,5.013,4.839,4.739,4.715,4.686,4.677,4.194,4.077,3.006],"y":[0.33172,0.26428,0.21542,0.32573,0.13706,0.16228,0.17362,0.18295,0.07822,0.12253,0.11053,0.07172,0.21854,0.06431,0.11251,0.38086,0.17922,0.11291,0.09131,0.47179],"type":"scatter"},{"marker":{"size":[0.95578,1.02054,0.98124,1.04424,1.06353,1.10715,1.05351,1.06166,0.91861,0.99534,1.21183,0.76454,0.74553,0.86402,0.68133,0.75985,0.59325,0.90019,0.81038,0.89537,0.59532,0.26673],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Latin America and Caribbean","text":["Costa Rica","Mexico","Brazil","Venezuela","Panama","Chile","Argentina","Uruguay","Colombia","Suriname","Trinidad and Tobago","El Salvador","Guatemala","Ecuador","Bolivia","Paraguay","Nicaragua","Peru","Jamaica","Dominican Republic","Honduras","Haiti"],"x":[7.226,7.187,6.983,6.81,6.786,6.67,6.574,6.485,6.477,6.269,6.168,6.13,6.123,5.975,5.89,5.878,5.828,5.824,5.709,4.885,4.788,4.518],"y":[0.25497,0.14074,0.14574,0.05841,0.24434,0.33363,0.11451,0.2324,0.18401,0.16991,0.31844,0.10692,0.27489,0.11541,0.20536,0.3424,0.27815,0.14982,0.2123,0.21684,0.23027,0.46187],"type":"scatter"},{"marker":{"size":[1.52186,0.9669,1.12486,0.82827,0.63216,0.70532,0.59066,0.27108,0.46038],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Southeastern Asia","text":["Singapore","Thailand","Malaysia","Indonesia","Vietnam","Philippines","Laos","Myanmar","Cambodia"],"x":[6.798,6.455,5.77,5.399,5.36,5.073,4.876,4.307,3.819],"y":[0.31105,0.5763,0.33075,0.51535,0.1686,0.24991,0.42192,0.79588,0.40359],"type":"scatter"},{"marker":{"size":[1.17898,0.63244,1.16891,0.59448,1.12254,1.18498,1.14723,1.03192,1.12555,1.08254,1.13764,0.80148,0.95847,1.15174,0.47428,1.02389,0.97438,1.04345,0.92053,1.11312,0.91851,0.87867,0.83223,1.12094,0.39047,0.79907,0.76821,0.7419,1.01216],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Central and Eastern Europe","text":["Czech Republic","Uzbekistan","Slovakia","Moldova","Kazakhstan","Slovenia","Lithuania","Belarus","Poland","Croatia","Russia","Kosovo","Turkmenistan","Estonia","Kyrgyzstan","Azerbaijan","Montenegro","Romania","Serbia","Latvia","Macedonia","Albania","Bosnia and Herzegovina","Hungary","Tajikistan","Ukraine","Armenia","Georgia","Bulgaria"],"x":[6.505,6.003,5.995,5.889,5.855,5.848,5.833,5.813,5.791,5.759,5.716,5.589,5.548,5.429,5.286,5.212,5.192,5.124,5.123,5.098,5.007,4.959,4.949,4.8,4.786,4.681,4.35,4.297,4.218],"y":[0.10686,0.22837,0.16893,0.20951,0.11827,0.25328,0.02641,0.11046,0.16759,0.05444,0.00199,0.2831,0.16979,0.0868,0.3003,0.07799,0.1614,0.13748,0.19231,0.18226,0.22359,0.14272,0.24808,0.128,0.22974,0.15275,0.07855,0.05547,0.11921],"type":"scatter"},{"marker":{"size":[1.29098,1.27074,1.24461,1.38604,0.89012,0.82819],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Eastern Asia","text":["Taiwan","Japan","South Korea","Hong Kong","China","Mongolia"],"x":[6.298,5.987,5.984,5.474,5.14,4.874],"y":[0.25376,0.10705,0.18557,0.39478,0.08185,0.3323],"type":"scatter"},{"marker":{"size":[1.00761,0.65435,0.47038,0.18847,0.08308,0.37545,0.71206,0.92049,0.54558,0.271,0.0712,0.52107,0.0,0.19073,0.33024,0.45407,0.36471,0.44025,0.99355,0.01604,0.4225,0.75778,0.26074,0.67866,0.23906,0.21102,0.36498,1.06024,0.0694,0.2852,0.20824,0.0785,0.34193,0.17417,0.46534,0.25812,0.22208,0.28665,0.0153,0.20868],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Sub-Saharan Africa","text":["Mauritius","Nigeria","Zambia","Somaliland region","Mozambique","Lesotho","Swaziland","South Africa","Ghana","Zimbabwe","Liberia","Sudan","Congo (Kinshasa)","Ethiopia","Sierra Leone","Mauritania","Kenya","Djibouti","Botswana","Malawi","Cameroon","Angola","Mali","Congo (Brazzaville)","Comoros","Uganda","Senegal","Gabon","Niger","Tanzania","Madagascar","Central African Republic","Chad","Guinea","Ivory Coast","Burkina Faso","Rwanda","Benin","Burundi","Togo"],"x":[5.477,5.268,5.129,5.057,4.971,4.898,4.867,4.642,4.633,4.61,4.571,4.55,4.517,4.512,4.507,4.436,4.419,4.369,4.332,4.292,4.252,4.033,3.995,3.989,3.956,3.931,3.904,3.896,3.845,3.781,3.681,3.678,3.667,3.656,3.655,3.587,3.465,3.34,2.905,2.839],"y":[0.37744,0.27233,0.19591,0.50318,0.22269,0.16388,0.18259,0.11973,0.23087,0.18987,0.24362,0.19062,0.24834,0.24325,0.21488,0.219,0.37542,0.18093,0.10461,0.33128,0.20618,0.12344,0.18798,0.12388,0.17441,0.29066,0.20843,0.06822,0.19387,0.34377,0.21333,0.23835,0.18386,0.28657,0.20165,0.21747,0.22628,0.1826,0.19727,0.16681],"type":"scatter"},{"marker":{"size":[0.77042,0.59543,0.39753,0.64499,0.35997,0.83524,0.31982],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Southern Asia","text":["Bhutan","Pakistan","Bangladesh","India","Nepal","Sri Lanka","Afghanistan"],"x":[5.253,5.194,4.694,4.565,4.514,4.271,3.575],"y":[0.47998,0.33671,0.21222,0.26475,0.32296,0.40828,0.3651],"type":"scatter"}],                        {"height":650,"hovermode":"closest","margin":{"b":50,"pad":5,"t":50},"showlegend":true,"template":{"data":{"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"choropleth":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"choropleth"}],"contourcarpet":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"contourcarpet"}],"contour":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"contour"}],"heatmapgl":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"heatmapgl"}],"heatmap":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"heatmap"}],"histogram2dcontour":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"histogram2dcontour"}],"histogram2d":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"histogram2d"}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"mesh3d":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"mesh3d"}],"parcoords":[{"line":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"parcoords"}],"pie":[{"automargin":true,"type":"pie"}],"scatter3d":[{"line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatter3d"}],"scattercarpet":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattercarpet"}],"scattergeo":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattergeo"}],"scattergl":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattergl"}],"scattermapbox":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattermapbox"}],"scatterpolargl":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterpolargl"}],"scatterpolar":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterpolar"}],"scatter":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatter"}],"scatterternary":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterternary"}],"surface":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"surface"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}]},"layout":{"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"autotypenumbers":"strict","coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]],"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]},"colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"geo":{"bgcolor":"white","lakecolor":"white","landcolor":"#E5ECF6","showlakes":true,"showland":true,"subunitcolor":"white"},"hoverlabel":{"align":"left"},"hovermode":"closest","mapbox":{"style":"light"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"bgcolor":"#E5ECF6","radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"ternary":{"aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"bgcolor":"#E5ECF6","caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"title":{"x":0.05},"xaxis":{"automargin":true,"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","zerolinewidth":2},"yaxis":{"automargin":true,"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","zerolinewidth":2}}},"title":{"text":"Happiness vs Generosity vs Economy"},"xaxis":{"autorange":false,"range":[1.9872999999999998,10.621799999999999],"title":{"text":"Happiness Score"}},"yaxis":{"autorange":false,"range":[0.0,1.114232],"title":{"text":"Generosity"}}},                        {"scrollzoom": true, "responsive": true}                    ).then(function(){

var gd = document.getElementById('a0689f03-02a9-4f09-8752-8cee6962ddab');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>



```python
import warnings
warnings.filterwarnings('ignore')

figure = bubbleplot(dataset = df, x_column = 'Happiness Score', y_column = 'Trust (Government Corruption)', 
    bubble_column = 'Country', size_column = 'Economy (GDP per Capita)', color_column = 'Region', 
    x_title = "Happiness Score", y_title = "Trust", title = 'Happiness vs Trust vs Economy',
    x_logscale = False, scale_bubble = 1, height = 650)

py.iplot(figure, config={'scrollzoom': True})
```


<div>                            <div id="307019e2-3797-4fcc-b4cb-c5d5c4f890b4" class="plotly-graph-div" style="height:650px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("307019e2-3797-4fcc-b4cb-c5d5c4f890b4")) {                    Plotly.newPlot(                        "307019e2-3797-4fcc-b4cb-c5d5c4f890b4",                        [{"marker":{"size":[1.39651,1.30232,1.32548,1.459,1.29025,1.32944,1.33171,1.33723,1.56391,1.33596,1.30782,1.26637,1.32792,1.27778,1.23011,1.2074,1.25114,1.20806,1.20813,1.15991,1.15406],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Western Europe","text":["Switzerland","Iceland","Denmark","Norway","Finland","Netherlands","Sweden","Austria","Luxembourg","Ireland","Belgium","United Kingdom","Germany","France","Spain","Malta","Italy","North Cyprus","Cyprus","Portugal","Greece"],"x":[7.587,7.561,7.527,7.522,7.406,7.378,7.364,7.2,6.946,6.94,6.937,6.867,6.75,6.575,6.329,6.302,5.948,5.695,5.689,5.102,4.857],"y":[0.41978,0.14145,0.48357,0.36503,0.41372,0.31814,0.43844,0.18676,0.37798,0.28703,0.2254,0.32067,0.21843,0.20646,0.06398,0.13586,0.02901,0.1428,0.06146,0.01078,0.01397],"type":"scatter"},{"marker":{"size":[1.32629,1.39451],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"North America","text":["Canada","United States"],"x":[7.427,7.119],"y":[0.32957,0.1589],"type":"scatter"},{"marker":{"size":[1.25018,1.33358],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Australia and New Zealand","text":["New Zealand","Australia"],"x":[7.286,7.284],"y":[0.42922,0.35637],"type":"scatter"},{"marker":{"size":[1.22857,1.42727,1.36011,1.69042,1.39541,1.55422,1.32376,1.13145,0.93929,1.06098,0.90198,0.73479,1.02564,0.88113,0.59867,1.0088,0.98549,0.8818,0.54649,0.6632],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Middle East and Northern Africa","text":["Israel","United Arab Emirates","Oman","Qatar","Saudi Arabia","Kuwait","Bahrain","Libya","Algeria","Turkey","Jordan","Morocco","Lebanon","Tunisia","Palestinian Territories","Iran","Iraq","Egypt","Yemen","Syria"],"x":[7.278,6.901,6.853,6.611,6.411,6.295,5.96,5.754,5.605,5.332,5.192,5.013,4.839,4.739,4.715,4.686,4.677,4.194,4.077,3.006],"y":[0.07785,0.38583,0.32524,0.52208,0.32524,0.25609,0.306,0.11023,0.17383,0.15746,0.14293,0.08546,0.04582,0.06358,0.12905,0.05863,0.13788,0.06324,0.07854,0.18906],"type":"scatter"},{"marker":{"size":[0.95578,1.02054,0.98124,1.04424,1.06353,1.10715,1.05351,1.06166,0.91861,0.99534,1.21183,0.76454,0.74553,0.86402,0.68133,0.75985,0.59325,0.90019,0.81038,0.89537,0.59532,0.26673],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Latin America and Caribbean","text":["Costa Rica","Mexico","Brazil","Venezuela","Panama","Chile","Argentina","Uruguay","Colombia","Suriname","Trinidad and Tobago","El Salvador","Guatemala","Ecuador","Bolivia","Paraguay","Nicaragua","Peru","Jamaica","Dominican Republic","Honduras","Haiti"],"x":[7.226,7.187,6.983,6.81,6.786,6.67,6.574,6.485,6.477,6.269,6.168,6.13,6.123,5.975,5.89,5.878,5.828,5.824,5.709,4.885,4.788,4.518],"y":[0.10583,0.21312,0.17521,0.11069,0.0927,0.12869,0.08484,0.24558,0.0512,0.13633,0.0114,0.11776,0.09472,0.1809,0.088,0.08242,0.19317,0.05989,0.02299,0.14234,0.06825,0.17175],"type":"scatter"},{"marker":{"size":[1.52186,0.9669,1.12486,0.82827,0.63216,0.70532,0.59066,0.27108,0.46038],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Southeastern Asia","text":["Singapore","Thailand","Malaysia","Indonesia","Vietnam","Philippines","Laos","Myanmar","Cambodia"],"x":[6.798,6.455,5.77,5.399,5.36,5.073,4.876,4.307,3.819],"y":[0.4921,0.03187,0.10501,0.0,0.10441,0.12279,0.24249,0.19034,0.07247],"type":"scatter"},{"marker":{"size":[1.17898,0.63244,1.16891,0.59448,1.12254,1.18498,1.14723,1.03192,1.12555,1.08254,1.13764,0.80148,0.95847,1.15174,0.47428,1.02389,0.97438,1.04345,0.92053,1.11312,0.91851,0.87867,0.83223,1.12094,0.39047,0.79907,0.76821,0.7419,1.01216],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Central and Eastern Europe","text":["Czech Republic","Uzbekistan","Slovakia","Moldova","Kazakhstan","Slovenia","Lithuania","Belarus","Poland","Croatia","Russia","Kosovo","Turkmenistan","Estonia","Kyrgyzstan","Azerbaijan","Montenegro","Romania","Serbia","Latvia","Macedonia","Albania","Bosnia and Herzegovina","Hungary","Tajikistan","Ukraine","Armenia","Georgia","Bulgaria"],"x":[6.505,6.003,5.995,5.889,5.855,5.848,5.833,5.813,5.791,5.759,5.716,5.589,5.548,5.429,5.286,5.212,5.192,5.124,5.123,5.098,5.007,4.959,4.949,4.8,4.786,4.681,4.35,4.297,4.218],"y":[0.02652,0.30826,0.03431,0.01615,0.08454,0.03787,0.01031,0.1909,0.04212,0.0243,0.03005,0.04741,0.30844,0.15184,0.04232,0.16065,0.14296,0.00649,0.02617,0.06332,0.05327,0.06413,0.00227,0.02758,0.15072,0.02961,0.039,0.38331,0.00872],"type":"scatter"},{"marker":{"size":[1.29098,1.27074,1.24461,1.38604,0.89012,0.82819],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Eastern Asia","text":["Taiwan","Japan","South Korea","Hong Kong","China","Mongolia"],"x":[6.298,5.987,5.984,5.474,5.14,4.874],"y":[0.08129,0.1806,0.07857,0.37124,0.02781,0.02666],"type":"scatter"},{"marker":{"size":[1.00761,0.65435,0.47038,0.18847,0.08308,0.37545,0.71206,0.92049,0.54558,0.271,0.0712,0.52107,0.0,0.19073,0.33024,0.45407,0.36471,0.44025,0.99355,0.01604,0.4225,0.75778,0.26074,0.67866,0.23906,0.21102,0.36498,1.06024,0.0694,0.2852,0.20824,0.0785,0.34193,0.17417,0.46534,0.25812,0.22208,0.28665,0.0153,0.20868],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Sub-Saharan Africa","text":["Mauritius","Nigeria","Zambia","Somaliland region","Mozambique","Lesotho","Swaziland","South Africa","Ghana","Zimbabwe","Liberia","Sudan","Congo (Kinshasa)","Ethiopia","Sierra Leone","Mauritania","Kenya","Djibouti","Botswana","Malawi","Cameroon","Angola","Mali","Congo (Brazzaville)","Comoros","Uganda","Senegal","Gabon","Niger","Tanzania","Madagascar","Central African Republic","Chad","Guinea","Ivory Coast","Burkina Faso","Rwanda","Benin","Burundi","Togo"],"x":[5.477,5.268,5.129,5.057,4.971,4.898,4.867,4.642,4.633,4.61,4.571,4.55,4.517,4.512,4.507,4.436,4.419,4.369,4.332,4.292,4.252,4.033,3.995,3.989,3.956,3.931,3.904,3.896,3.845,3.781,3.681,3.678,3.667,3.656,3.655,3.587,3.465,3.34,2.905,2.839],"y":[0.07521,0.0403,0.12468,0.39928,0.15603,0.12504,0.0306,0.08884,0.04355,0.08079,0.06232,0.1466,0.07625,0.15048,0.08786,0.17461,0.05839,0.28105,0.12474,0.06977,0.05786,0.07122,0.12352,0.11686,0.199,0.07267,0.10713,0.11091,0.15639,0.05747,0.08124,0.08289,0.05269,0.12139,0.17922,0.12832,0.55191,0.0801,0.10062,0.10731],"type":"scatter"},{"marker":{"size":[0.77042,0.59543,0.39753,0.64499,0.35997,0.83524,0.31982],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Southern Asia","text":["Bhutan","Pakistan","Bangladesh","India","Nepal","Sri Lanka","Afghanistan"],"x":[5.253,5.194,4.694,4.565,4.514,4.271,3.575],"y":[0.15445,0.10464,0.12569,0.08492,0.05907,0.09179,0.09719],"type":"scatter"}],                        {"height":650,"hovermode":"closest","margin":{"b":50,"pad":5,"t":50},"showlegend":true,"template":{"data":{"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"choropleth":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"choropleth"}],"contourcarpet":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"contourcarpet"}],"contour":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"contour"}],"heatmapgl":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"heatmapgl"}],"heatmap":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"heatmap"}],"histogram2dcontour":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"histogram2dcontour"}],"histogram2d":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"histogram2d"}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"mesh3d":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"mesh3d"}],"parcoords":[{"line":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"parcoords"}],"pie":[{"automargin":true,"type":"pie"}],"scatter3d":[{"line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatter3d"}],"scattercarpet":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattercarpet"}],"scattergeo":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattergeo"}],"scattergl":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattergl"}],"scattermapbox":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattermapbox"}],"scatterpolargl":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterpolargl"}],"scatterpolar":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterpolar"}],"scatter":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatter"}],"scatterternary":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterternary"}],"surface":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"surface"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}]},"layout":{"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"autotypenumbers":"strict","coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]],"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]},"colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"geo":{"bgcolor":"white","lakecolor":"white","landcolor":"#E5ECF6","showlakes":true,"showland":true,"subunitcolor":"white"},"hoverlabel":{"align":"left"},"hovermode":"closest","mapbox":{"style":"light"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"bgcolor":"#E5ECF6","radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"ternary":{"aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"bgcolor":"#E5ECF6","caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"title":{"x":0.05},"xaxis":{"automargin":true,"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","zerolinewidth":2},"yaxis":{"automargin":true,"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","zerolinewidth":2}}},"title":{"text":"Happiness vs Trust vs Economy"},"xaxis":{"autorange":false,"range":[1.9872999999999998,10.621799999999999],"title":{"text":"Happiness Score"}},"yaxis":{"autorange":false,"range":[0.0,0.772674],"title":{"text":"Trust"}}},                        {"scrollzoom": true, "responsive": true}                    ).then(function(){

var gd = document.getElementById('307019e2-3797-4fcc-b4cb-c5d5c4f890b4');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>



```python
import warnings
warnings.filterwarnings('ignore')

figure = bubbleplot(dataset = df, x_column = 'Happiness Score', y_column = 'Health (Life Expectancy)', 
    bubble_column = 'Country', size_column = 'Economy (GDP per Capita)', color_column = 'Region', 
    x_title = "Happiness Score", y_title = "Health", title = 'Happiness vs Health vs Economy',
    x_logscale = False, scale_bubble = 1, height = 650)

py.iplot(figure, config={'scrollzoom': True})

```


<div>                            <div id="d3e83f0c-55cb-4e75-a59f-41c5a6da82ea" class="plotly-graph-div" style="height:650px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("d3e83f0c-55cb-4e75-a59f-41c5a6da82ea")) {                    Plotly.newPlot(                        "d3e83f0c-55cb-4e75-a59f-41c5a6da82ea",                        [{"marker":{"size":[1.39651,1.30232,1.32548,1.459,1.29025,1.32944,1.33171,1.33723,1.56391,1.33596,1.30782,1.26637,1.32792,1.27778,1.23011,1.2074,1.25114,1.20806,1.20813,1.15991,1.15406],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Western Europe","text":["Switzerland","Iceland","Denmark","Norway","Finland","Netherlands","Sweden","Austria","Luxembourg","Ireland","Belgium","United Kingdom","Germany","France","Spain","Malta","Italy","North Cyprus","Cyprus","Portugal","Greece"],"x":[7.587,7.561,7.527,7.522,7.406,7.378,7.364,7.2,6.946,6.94,6.937,6.867,6.75,6.575,6.329,6.302,5.948,5.695,5.689,5.102,4.857],"y":[0.94143,0.94784,0.87464,0.88521,0.88911,0.89284,0.91087,0.89042,0.91894,0.89533,0.89667,0.90943,0.89186,0.94579,0.95562,0.88721,0.95446,0.92356,0.92356,0.87519,0.88213],"type":"scatter"},{"marker":{"size":[1.32629,1.39451],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"North America","text":["Canada","United States"],"x":[7.427,7.119],"y":[0.90563,0.86179],"type":"scatter"},{"marker":{"size":[1.25018,1.33358],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Australia and New Zealand","text":["New Zealand","Australia"],"x":[7.286,7.284],"y":[0.90837,0.93156],"type":"scatter"},{"marker":{"size":[1.22857,1.42727,1.36011,1.69042,1.39541,1.55422,1.32376,1.13145,0.93929,1.06098,0.90198,0.73479,1.02564,0.88113,0.59867,1.0088,0.98549,0.8818,0.54649,0.6632],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Middle East and Northern Africa","text":["Israel","United Arab Emirates","Oman","Qatar","Saudi Arabia","Kuwait","Bahrain","Libya","Algeria","Turkey","Jordan","Morocco","Lebanon","Tunisia","Palestinian Territories","Iran","Iraq","Egypt","Yemen","Syria"],"x":[7.278,6.901,6.853,6.611,6.411,6.295,5.96,5.754,5.605,5.332,5.192,5.013,4.839,4.739,4.715,4.686,4.677,4.194,4.077,3.006],"y":[0.91387,0.80925,0.76276,0.79733,0.72025,0.72492,0.74716,0.7038,0.61766,0.73172,0.69639,0.60954,0.83947,0.73793,0.66015,0.69805,0.60237,0.61712,0.40064,0.72193],"type":"scatter"},{"marker":{"size":[0.95578,1.02054,0.98124,1.04424,1.06353,1.10715,1.05351,1.06166,0.91861,0.99534,1.21183,0.76454,0.74553,0.86402,0.68133,0.75985,0.59325,0.90019,0.81038,0.89537,0.59532,0.26673],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Latin America and Caribbean","text":["Costa Rica","Mexico","Brazil","Venezuela","Panama","Chile","Argentina","Uruguay","Colombia","Suriname","Trinidad and Tobago","El Salvador","Guatemala","Ecuador","Bolivia","Paraguay","Nicaragua","Peru","Jamaica","Dominican Republic","Honduras","Haiti"],"x":[7.226,7.187,6.983,6.81,6.786,6.67,6.574,6.485,6.477,6.269,6.168,6.13,6.123,5.975,5.89,5.878,5.828,5.824,5.709,4.885,4.788,4.518],"y":[0.86027,0.81444,0.69702,0.72052,0.79661,0.85857,0.78723,0.8116,0.69077,0.6082,0.61483,0.67737,0.64425,0.79075,0.5392,0.66098,0.74314,0.73017,0.68741,0.66825,0.6951,0.38847],"type":"scatter"},{"marker":{"size":[1.52186,0.9669,1.12486,0.82827,0.63216,0.70532,0.59066,0.27108,0.46038],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Southeastern Asia","text":["Singapore","Thailand","Malaysia","Indonesia","Vietnam","Philippines","Laos","Myanmar","Cambodia"],"x":[6.798,6.455,5.77,5.399,5.36,5.073,4.876,4.307,3.819],"y":[1.02525,0.7385,0.72394,0.63793,0.74676,0.58114,0.54909,0.48246,0.61114],"type":"scatter"},{"marker":{"size":[1.17898,0.63244,1.16891,0.59448,1.12254,1.18498,1.14723,1.03192,1.12555,1.08254,1.13764,0.80148,0.95847,1.15174,0.47428,1.02389,0.97438,1.04345,0.92053,1.11312,0.91851,0.87867,0.83223,1.12094,0.39047,0.79907,0.76821,0.7419,1.01216],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Central and Eastern Europe","text":["Czech Republic","Uzbekistan","Slovakia","Moldova","Kazakhstan","Slovenia","Lithuania","Belarus","Poland","Croatia","Russia","Kosovo","Turkmenistan","Estonia","Kyrgyzstan","Azerbaijan","Montenegro","Romania","Serbia","Latvia","Macedonia","Albania","Bosnia and Herzegovina","Hungary","Tajikistan","Ukraine","Armenia","Georgia","Bulgaria"],"x":[6.505,6.003,5.995,5.889,5.855,5.848,5.833,5.813,5.791,5.759,5.716,5.589,5.548,5.429,5.286,5.212,5.192,5.124,5.123,5.098,5.007,4.959,4.949,4.8,4.786,4.681,4.35,4.297,4.218],"y":[0.84483,0.59772,0.78902,0.61826,0.64368,0.87337,0.73128,0.73608,0.77903,0.78805,0.66926,0.63132,0.53886,0.77361,0.65088,0.64045,0.72521,0.7689,0.74836,0.72437,0.73545,0.81325,0.79081,0.75905,0.57379,0.6739,0.7299,0.72926,0.76649],"type":"scatter"},{"marker":{"size":[1.29098,1.27074,1.24461,1.38604,0.89012,0.82819],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Eastern Asia","text":["Taiwan","Japan","South Korea","Hong Kong","China","Mongolia"],"x":[6.298,5.987,5.984,5.474,5.14,4.874],"y":[0.8753,0.99111,0.96538,1.01328,0.81658,0.60268],"type":"scatter"},{"marker":{"size":[1.00761,0.65435,0.47038,0.18847,0.08308,0.37545,0.71206,0.92049,0.54558,0.271,0.0712,0.52107,0.0,0.19073,0.33024,0.45407,0.36471,0.44025,0.99355,0.01604,0.4225,0.75778,0.26074,0.67866,0.23906,0.21102,0.36498,1.06024,0.0694,0.2852,0.20824,0.0785,0.34193,0.17417,0.46534,0.25812,0.22208,0.28665,0.0153,0.20868],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Sub-Saharan Africa","text":["Mauritius","Nigeria","Zambia","Somaliland region","Mozambique","Lesotho","Swaziland","South Africa","Ghana","Zimbabwe","Liberia","Sudan","Congo (Kinshasa)","Ethiopia","Sierra Leone","Mauritania","Kenya","Djibouti","Botswana","Malawi","Cameroon","Angola","Mali","Congo (Brazzaville)","Comoros","Uganda","Senegal","Gabon","Niger","Tanzania","Madagascar","Central African Republic","Chad","Guinea","Ivory Coast","Burkina Faso","Rwanda","Benin","Burundi","Togo"],"x":[5.477,5.268,5.129,5.057,4.971,4.898,4.867,4.642,4.633,4.61,4.571,4.55,4.517,4.512,4.507,4.436,4.419,4.369,4.332,4.292,4.252,4.033,3.995,3.989,3.956,3.931,3.904,3.896,3.845,3.781,3.681,3.678,3.667,3.656,3.655,3.587,3.465,3.34,2.905,2.839],"y":[0.7095,0.16007,0.29924,0.43873,0.09131,0.07612,0.07566,0.27688,0.40132,0.33475,0.34201,0.36878,0.09806,0.44055,0.0,0.35874,0.41435,0.36291,0.04776,0.22562,0.23402,0.16683,0.20583,0.31051,0.36315,0.33861,0.4354,0.43372,0.29707,0.38215,0.46721,0.06699,0.1501,0.24009,0.15185,0.27125,0.42864,0.3191,0.22396,0.28443],"type":"scatter"},{"marker":{"size":[0.77042,0.59543,0.39753,0.64499,0.35997,0.83524,0.31982],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Southern Asia","text":["Bhutan","Pakistan","Bangladesh","India","Nepal","Sri Lanka","Afghanistan"],"x":[5.253,5.194,4.694,4.565,4.514,4.271,3.575],"y":[0.57407,0.51466,0.60164,0.51529,0.56874,0.70806,0.30335],"type":"scatter"}],                        {"height":650,"hovermode":"closest","margin":{"b":50,"pad":5,"t":50},"showlegend":true,"template":{"data":{"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"choropleth":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"choropleth"}],"contourcarpet":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"contourcarpet"}],"contour":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"contour"}],"heatmapgl":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"heatmapgl"}],"heatmap":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"heatmap"}],"histogram2dcontour":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"histogram2dcontour"}],"histogram2d":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"histogram2d"}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"mesh3d":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"mesh3d"}],"parcoords":[{"line":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"parcoords"}],"pie":[{"automargin":true,"type":"pie"}],"scatter3d":[{"line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatter3d"}],"scattercarpet":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattercarpet"}],"scattergeo":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattergeo"}],"scattergl":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattergl"}],"scattermapbox":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattermapbox"}],"scatterpolargl":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterpolargl"}],"scatterpolar":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterpolar"}],"scatter":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatter"}],"scatterternary":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterternary"}],"surface":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"surface"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}]},"layout":{"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"autotypenumbers":"strict","coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]],"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]},"colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"geo":{"bgcolor":"white","lakecolor":"white","landcolor":"#E5ECF6","showlakes":true,"showland":true,"subunitcolor":"white"},"hoverlabel":{"align":"left"},"hovermode":"closest","mapbox":{"style":"light"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"bgcolor":"#E5ECF6","radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"ternary":{"aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"bgcolor":"#E5ECF6","caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"title":{"x":0.05},"xaxis":{"automargin":true,"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","zerolinewidth":2},"yaxis":{"automargin":true,"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","zerolinewidth":2}}},"title":{"text":"Happiness vs Health vs Economy"},"xaxis":{"autorange":false,"range":[1.9872999999999998,10.621799999999999],"title":{"text":"Happiness Score"}},"yaxis":{"autorange":false,"range":[0.0,1.43535],"title":{"text":"Health"}}},                        {"scrollzoom": true, "responsive": true}                    ).then(function(){

var gd = document.getElementById('d3e83f0c-55cb-4e75-a59f-41c5a6da82ea');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>



```python
import warnings
warnings.filterwarnings('ignore')

figure = bubbleplot(dataset = df, x_column = 'Happiness Score', y_column = 'Family', 
    bubble_column = 'Country', size_column = 'Economy (GDP per Capita)', color_column = 'Region', 
    x_title = "Happiness Score", y_title = "Family", title = 'Happiness vs Family vs Economy',
    x_logscale = False, scale_bubble = 1, height = 650)

py.iplot(figure, config={'scrollzoom': True})
```


<div>                            <div id="f4f6ca01-955b-419f-ada8-6a03ff98cc77" class="plotly-graph-div" style="height:650px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("f4f6ca01-955b-419f-ada8-6a03ff98cc77")) {                    Plotly.newPlot(                        "f4f6ca01-955b-419f-ada8-6a03ff98cc77",                        [{"marker":{"size":[1.39651,1.30232,1.32548,1.459,1.29025,1.32944,1.33171,1.33723,1.56391,1.33596,1.30782,1.26637,1.32792,1.27778,1.23011,1.2074,1.25114,1.20806,1.20813,1.15991,1.15406],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Western Europe","text":["Switzerland","Iceland","Denmark","Norway","Finland","Netherlands","Sweden","Austria","Luxembourg","Ireland","Belgium","United Kingdom","Germany","France","Spain","Malta","Italy","North Cyprus","Cyprus","Portugal","Greece"],"x":[7.587,7.561,7.527,7.522,7.406,7.378,7.364,7.2,6.946,6.94,6.937,6.867,6.75,6.575,6.329,6.302,5.948,5.695,5.689,5.102,4.857],"y":[1.34951,1.40223,1.36058,1.33095,1.31826,1.28017,1.28907,1.29704,1.21963,1.36948,1.28566,1.28548,1.29937,1.26038,1.31379,1.30203,1.19777,1.07008,0.89318,1.13935,0.92933],"type":"scatter"},{"marker":{"size":[1.32629,1.39451],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"North America","text":["Canada","United States"],"x":[7.427,7.119],"y":[1.32261,1.24711],"type":"scatter"},{"marker":{"size":[1.25018,1.33358],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Australia and New Zealand","text":["New Zealand","Australia"],"x":[7.286,7.284],"y":[1.31967,1.30923],"type":"scatter"},{"marker":{"size":[1.22857,1.42727,1.36011,1.69042,1.39541,1.55422,1.32376,1.13145,0.93929,1.06098,0.90198,0.73479,1.02564,0.88113,0.59867,1.0088,0.98549,0.8818,0.54649,0.6632],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Middle East and Northern Africa","text":["Israel","United Arab Emirates","Oman","Qatar","Saudi Arabia","Kuwait","Bahrain","Libya","Algeria","Turkey","Jordan","Morocco","Lebanon","Tunisia","Palestinian Territories","Iran","Iraq","Egypt","Yemen","Syria"],"x":[7.278,6.901,6.853,6.611,6.411,6.295,5.96,5.754,5.605,5.332,5.192,5.013,4.839,4.739,4.715,4.686,4.677,4.194,4.077,3.006],"y":[1.22393,1.12575,1.08182,1.0786,1.08393,1.16594,1.21624,1.11862,1.07772,0.94632,1.05392,0.64095,0.80001,0.60429,0.92558,0.54447,0.81889,0.747,0.68093,0.47489],"type":"scatter"},{"marker":{"size":[0.95578,1.02054,0.98124,1.04424,1.06353,1.10715,1.05351,1.06166,0.91861,0.99534,1.21183,0.76454,0.74553,0.86402,0.68133,0.75985,0.59325,0.90019,0.81038,0.89537,0.59532,0.26673],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Latin America and Caribbean","text":["Costa Rica","Mexico","Brazil","Venezuela","Panama","Chile","Argentina","Uruguay","Colombia","Suriname","Trinidad and Tobago","El Salvador","Guatemala","Ecuador","Bolivia","Paraguay","Nicaragua","Peru","Jamaica","Dominican Republic","Honduras","Haiti"],"x":[7.226,7.187,6.983,6.81,6.786,6.67,6.574,6.485,6.477,6.269,6.168,6.13,6.123,5.975,5.89,5.878,5.828,5.824,5.709,4.885,4.788,4.518],"y":[1.23788,0.91451,1.23287,1.25596,1.1985,1.12447,1.24823,1.2089,1.24018,0.972,1.18354,1.02507,1.04356,0.99903,0.97841,1.30477,1.14184,0.97459,1.15102,1.17202,0.95348,0.74302],"type":"scatter"},{"marker":{"size":[1.52186,0.9669,1.12486,0.82827,0.63216,0.70532,0.59066,0.27108,0.46038],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Southeastern Asia","text":["Singapore","Thailand","Malaysia","Indonesia","Vietnam","Philippines","Laos","Myanmar","Cambodia"],"x":[6.798,6.455,5.77,5.399,5.36,5.073,4.876,4.307,3.819],"y":[1.02,1.26504,1.07023,1.08708,0.91226,1.03516,0.73803,0.70905,0.62736],"type":"scatter"},{"marker":{"size":[1.17898,0.63244,1.16891,0.59448,1.12254,1.18498,1.14723,1.03192,1.12555,1.08254,1.13764,0.80148,0.95847,1.15174,0.47428,1.02389,0.97438,1.04345,0.92053,1.11312,0.91851,0.87867,0.83223,1.12094,0.39047,0.79907,0.76821,0.7419,1.01216],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Central and Eastern Europe","text":["Czech Republic","Uzbekistan","Slovakia","Moldova","Kazakhstan","Slovenia","Lithuania","Belarus","Poland","Croatia","Russia","Kosovo","Turkmenistan","Estonia","Kyrgyzstan","Azerbaijan","Montenegro","Romania","Serbia","Latvia","Macedonia","Albania","Bosnia and Herzegovina","Hungary","Tajikistan","Ukraine","Armenia","Georgia","Bulgaria"],"x":[6.505,6.003,5.995,5.889,5.855,5.848,5.833,5.813,5.791,5.759,5.716,5.589,5.548,5.429,5.286,5.212,5.192,5.124,5.123,5.098,5.007,4.959,4.949,4.8,4.786,4.681,4.35,4.297,4.218],"y":[1.20643,1.34043,1.26999,1.01528,1.12241,1.27385,1.25745,1.23289,1.27948,0.79624,1.23617,0.81198,1.22668,1.22791,1.15115,0.93793,0.90557,0.88588,1.00964,1.09562,1.00232,0.80434,0.91916,1.20215,0.85563,1.20278,0.77711,0.38562,1.10614],"type":"scatter"},{"marker":{"size":[1.29098,1.27074,1.24461,1.38604,0.89012,0.82819],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Eastern Asia","text":["Taiwan","Japan","South Korea","Hong Kong","China","Mongolia"],"x":[6.298,5.987,5.984,5.474,5.14,4.874],"y":[1.07617,1.25712,0.95774,1.05818,0.94675,1.3006],"type":"scatter"},{"marker":{"size":[1.00761,0.65435,0.47038,0.18847,0.08308,0.37545,0.71206,0.92049,0.54558,0.271,0.0712,0.52107,0.0,0.19073,0.33024,0.45407,0.36471,0.44025,0.99355,0.01604,0.4225,0.75778,0.26074,0.67866,0.23906,0.21102,0.36498,1.06024,0.0694,0.2852,0.20824,0.0785,0.34193,0.17417,0.46534,0.25812,0.22208,0.28665,0.0153,0.20868],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Sub-Saharan Africa","text":["Mauritius","Nigeria","Zambia","Somaliland region","Mozambique","Lesotho","Swaziland","South Africa","Ghana","Zimbabwe","Liberia","Sudan","Congo (Kinshasa)","Ethiopia","Sierra Leone","Mauritania","Kenya","Djibouti","Botswana","Malawi","Cameroon","Angola","Mali","Congo (Brazzaville)","Comoros","Uganda","Senegal","Gabon","Niger","Tanzania","Madagascar","Central African Republic","Chad","Guinea","Ivory Coast","Burkina Faso","Rwanda","Benin","Burundi","Togo"],"x":[5.477,5.268,5.129,5.057,4.971,4.898,4.867,4.642,4.633,4.61,4.571,4.55,4.517,4.512,4.507,4.436,4.419,4.369,4.332,4.292,4.252,4.033,3.995,3.989,3.956,3.931,3.904,3.896,3.845,3.781,3.681,3.678,3.667,3.656,3.655,3.587,3.465,3.34,2.905,2.839],"y":[0.98521,0.90432,0.91612,0.95152,1.02626,1.04103,1.07284,1.18468,0.67954,1.03276,0.78968,1.01404,1.0012,0.60406,0.95571,0.86908,0.99876,0.59207,1.10464,0.41134,0.88767,0.8604,1.03526,0.6629,0.79273,1.13299,0.97619,0.90528,0.77265,1.00268,0.66801,0.0,0.76062,0.46475,0.77115,0.85188,0.7737,0.35386,0.41587,0.13995],"type":"scatter"},{"marker":{"size":[0.77042,0.59543,0.39753,0.64499,0.35997,0.83524,0.31982],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Southern Asia","text":["Bhutan","Pakistan","Bangladesh","India","Nepal","Sri Lanka","Afghanistan"],"x":[5.253,5.194,4.694,4.565,4.514,4.271,3.575],"y":[1.10395,0.41411,0.43106,0.38174,0.86449,1.01905,0.30285],"type":"scatter"}],                        {"height":650,"hovermode":"closest","margin":{"b":50,"pad":5,"t":50},"showlegend":true,"template":{"data":{"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"choropleth":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"choropleth"}],"contourcarpet":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"contourcarpet"}],"contour":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"contour"}],"heatmapgl":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"heatmapgl"}],"heatmap":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"heatmap"}],"histogram2dcontour":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"histogram2dcontour"}],"histogram2d":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"histogram2d"}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"mesh3d":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"mesh3d"}],"parcoords":[{"line":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"parcoords"}],"pie":[{"automargin":true,"type":"pie"}],"scatter3d":[{"line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatter3d"}],"scattercarpet":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattercarpet"}],"scattergeo":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattergeo"}],"scattergl":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattergl"}],"scattermapbox":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattermapbox"}],"scatterpolargl":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterpolargl"}],"scatterpolar":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterpolar"}],"scatter":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatter"}],"scatterternary":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterternary"}],"surface":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"surface"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}]},"layout":{"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"autotypenumbers":"strict","coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]],"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]},"colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"geo":{"bgcolor":"white","lakecolor":"white","landcolor":"#E5ECF6","showlakes":true,"showland":true,"subunitcolor":"white"},"hoverlabel":{"align":"left"},"hovermode":"closest","mapbox":{"style":"light"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"bgcolor":"#E5ECF6","radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"ternary":{"aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"bgcolor":"#E5ECF6","caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"title":{"x":0.05},"xaxis":{"automargin":true,"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","zerolinewidth":2},"yaxis":{"automargin":true,"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","zerolinewidth":2}}},"title":{"text":"Happiness vs Family vs Economy"},"xaxis":{"autorange":false,"range":[1.9872999999999998,10.621799999999999],"title":{"text":"Happiness Score"}},"yaxis":{"autorange":false,"range":[0.0,1.963122],"title":{"text":"Family"}}},                        {"scrollzoom": true, "responsive": true}                    ).then(function(){

var gd = document.getElementById('f4f6ca01-955b-419f-ada8-6a03ff98cc77');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>


##### Bubble plot to depict the relation between the Happiness Scores vs Family Satisfaction where size of the bubbles is represented by the Economy and the color of the bubbles is represented by the Different Regions of the World.

#### It is Quite Visible that as the Family Satisfaction ratings increases the Happiness Score increases. So, We can say that they have a direct relationship between them.

Also, European Countries and Austrelia are the Happiest Regions. After America.

There is not even a single country in American Region with low Happiness Index.

Asian and African countries suffer with some serious issues, that is why none of the Asian orr African Country stands at a good position in terms of Happiness Index.

Some Countries in Middle East are Happy while some are Unhappy.


```python
import warnings
warnings.filterwarnings('ignore')

figure = bubbleplot(dataset = df, x_column = 'Happiness Score', y_column = 'Generosity', 
    bubble_column = 'Country', size_column = 'Economy (GDP per Capita)', color_column = 'Region', 
    x_title = "Happiness Score", y_title = "Generosity", title = 'Happiness vs Generosity vs Economy',
    x_logscale = False, scale_bubble = 1, height = 650)

py.iplot(figure, config={'scrollzoom': True})
```


<div>                            <div id="ca99ba77-4e96-4de0-a562-1e4841089623" class="plotly-graph-div" style="height:650px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("ca99ba77-4e96-4de0-a562-1e4841089623")) {                    Plotly.newPlot(                        "ca99ba77-4e96-4de0-a562-1e4841089623",                        [{"marker":{"size":[1.39651,1.30232,1.32548,1.459,1.29025,1.32944,1.33171,1.33723,1.56391,1.33596,1.30782,1.26637,1.32792,1.27778,1.23011,1.2074,1.25114,1.20806,1.20813,1.15991,1.15406],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Western Europe","text":["Switzerland","Iceland","Denmark","Norway","Finland","Netherlands","Sweden","Austria","Luxembourg","Ireland","Belgium","United Kingdom","Germany","France","Spain","Malta","Italy","North Cyprus","Cyprus","Portugal","Greece"],"x":[7.587,7.561,7.527,7.522,7.406,7.378,7.364,7.2,6.946,6.94,6.937,6.867,6.75,6.575,6.329,6.302,5.948,5.695,5.689,5.102,4.857],"y":[0.29678,0.4363,0.34139,0.34699,0.23351,0.4761,0.36262,0.33088,0.28034,0.45901,0.2225,0.51912,0.28214,0.12332,0.18227,0.51752,0.22823,0.26169,0.30638,0.13719,0.0],"type":"scatter"},{"marker":{"size":[1.32629,1.39451],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"North America","text":["Canada","United States"],"x":[7.427,7.119],"y":[0.45811,0.40105],"type":"scatter"},{"marker":{"size":[1.25018,1.33358],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Australia and New Zealand","text":["New Zealand","Australia"],"x":[7.286,7.284],"y":[0.47501,0.43562],"type":"scatter"},{"marker":{"size":[1.22857,1.42727,1.36011,1.69042,1.39541,1.55422,1.32376,1.13145,0.93929,1.06098,0.90198,0.73479,1.02564,0.88113,0.59867,1.0088,0.98549,0.8818,0.54649,0.6632],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Middle East and Northern Africa","text":["Israel","United Arab Emirates","Oman","Qatar","Saudi Arabia","Kuwait","Bahrain","Libya","Algeria","Turkey","Jordan","Morocco","Lebanon","Tunisia","Palestinian Territories","Iran","Iraq","Egypt","Yemen","Syria"],"x":[7.278,6.901,6.853,6.611,6.411,6.295,5.96,5.754,5.605,5.332,5.192,5.013,4.839,4.739,4.715,4.686,4.677,4.194,4.077,3.006],"y":[0.33172,0.26428,0.21542,0.32573,0.13706,0.16228,0.17362,0.18295,0.07822,0.12253,0.11053,0.07172,0.21854,0.06431,0.11251,0.38086,0.17922,0.11291,0.09131,0.47179],"type":"scatter"},{"marker":{"size":[0.95578,1.02054,0.98124,1.04424,1.06353,1.10715,1.05351,1.06166,0.91861,0.99534,1.21183,0.76454,0.74553,0.86402,0.68133,0.75985,0.59325,0.90019,0.81038,0.89537,0.59532,0.26673],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Latin America and Caribbean","text":["Costa Rica","Mexico","Brazil","Venezuela","Panama","Chile","Argentina","Uruguay","Colombia","Suriname","Trinidad and Tobago","El Salvador","Guatemala","Ecuador","Bolivia","Paraguay","Nicaragua","Peru","Jamaica","Dominican Republic","Honduras","Haiti"],"x":[7.226,7.187,6.983,6.81,6.786,6.67,6.574,6.485,6.477,6.269,6.168,6.13,6.123,5.975,5.89,5.878,5.828,5.824,5.709,4.885,4.788,4.518],"y":[0.25497,0.14074,0.14574,0.05841,0.24434,0.33363,0.11451,0.2324,0.18401,0.16991,0.31844,0.10692,0.27489,0.11541,0.20536,0.3424,0.27815,0.14982,0.2123,0.21684,0.23027,0.46187],"type":"scatter"},{"marker":{"size":[1.52186,0.9669,1.12486,0.82827,0.63216,0.70532,0.59066,0.27108,0.46038],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Southeastern Asia","text":["Singapore","Thailand","Malaysia","Indonesia","Vietnam","Philippines","Laos","Myanmar","Cambodia"],"x":[6.798,6.455,5.77,5.399,5.36,5.073,4.876,4.307,3.819],"y":[0.31105,0.5763,0.33075,0.51535,0.1686,0.24991,0.42192,0.79588,0.40359],"type":"scatter"},{"marker":{"size":[1.17898,0.63244,1.16891,0.59448,1.12254,1.18498,1.14723,1.03192,1.12555,1.08254,1.13764,0.80148,0.95847,1.15174,0.47428,1.02389,0.97438,1.04345,0.92053,1.11312,0.91851,0.87867,0.83223,1.12094,0.39047,0.79907,0.76821,0.7419,1.01216],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Central and Eastern Europe","text":["Czech Republic","Uzbekistan","Slovakia","Moldova","Kazakhstan","Slovenia","Lithuania","Belarus","Poland","Croatia","Russia","Kosovo","Turkmenistan","Estonia","Kyrgyzstan","Azerbaijan","Montenegro","Romania","Serbia","Latvia","Macedonia","Albania","Bosnia and Herzegovina","Hungary","Tajikistan","Ukraine","Armenia","Georgia","Bulgaria"],"x":[6.505,6.003,5.995,5.889,5.855,5.848,5.833,5.813,5.791,5.759,5.716,5.589,5.548,5.429,5.286,5.212,5.192,5.124,5.123,5.098,5.007,4.959,4.949,4.8,4.786,4.681,4.35,4.297,4.218],"y":[0.10686,0.22837,0.16893,0.20951,0.11827,0.25328,0.02641,0.11046,0.16759,0.05444,0.00199,0.2831,0.16979,0.0868,0.3003,0.07799,0.1614,0.13748,0.19231,0.18226,0.22359,0.14272,0.24808,0.128,0.22974,0.15275,0.07855,0.05547,0.11921],"type":"scatter"},{"marker":{"size":[1.29098,1.27074,1.24461,1.38604,0.89012,0.82819],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Eastern Asia","text":["Taiwan","Japan","South Korea","Hong Kong","China","Mongolia"],"x":[6.298,5.987,5.984,5.474,5.14,4.874],"y":[0.25376,0.10705,0.18557,0.39478,0.08185,0.3323],"type":"scatter"},{"marker":{"size":[1.00761,0.65435,0.47038,0.18847,0.08308,0.37545,0.71206,0.92049,0.54558,0.271,0.0712,0.52107,0.0,0.19073,0.33024,0.45407,0.36471,0.44025,0.99355,0.01604,0.4225,0.75778,0.26074,0.67866,0.23906,0.21102,0.36498,1.06024,0.0694,0.2852,0.20824,0.0785,0.34193,0.17417,0.46534,0.25812,0.22208,0.28665,0.0153,0.20868],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Sub-Saharan Africa","text":["Mauritius","Nigeria","Zambia","Somaliland region","Mozambique","Lesotho","Swaziland","South Africa","Ghana","Zimbabwe","Liberia","Sudan","Congo (Kinshasa)","Ethiopia","Sierra Leone","Mauritania","Kenya","Djibouti","Botswana","Malawi","Cameroon","Angola","Mali","Congo (Brazzaville)","Comoros","Uganda","Senegal","Gabon","Niger","Tanzania","Madagascar","Central African Republic","Chad","Guinea","Ivory Coast","Burkina Faso","Rwanda","Benin","Burundi","Togo"],"x":[5.477,5.268,5.129,5.057,4.971,4.898,4.867,4.642,4.633,4.61,4.571,4.55,4.517,4.512,4.507,4.436,4.419,4.369,4.332,4.292,4.252,4.033,3.995,3.989,3.956,3.931,3.904,3.896,3.845,3.781,3.681,3.678,3.667,3.656,3.655,3.587,3.465,3.34,2.905,2.839],"y":[0.37744,0.27233,0.19591,0.50318,0.22269,0.16388,0.18259,0.11973,0.23087,0.18987,0.24362,0.19062,0.24834,0.24325,0.21488,0.219,0.37542,0.18093,0.10461,0.33128,0.20618,0.12344,0.18798,0.12388,0.17441,0.29066,0.20843,0.06822,0.19387,0.34377,0.21333,0.23835,0.18386,0.28657,0.20165,0.21747,0.22628,0.1826,0.19727,0.16681],"type":"scatter"},{"marker":{"size":[0.77042,0.59543,0.39753,0.64499,0.35997,0.83524,0.31982],"sizemode":"area","sizeref":0.00052825625},"mode":"markers","name":"Southern Asia","text":["Bhutan","Pakistan","Bangladesh","India","Nepal","Sri Lanka","Afghanistan"],"x":[5.253,5.194,4.694,4.565,4.514,4.271,3.575],"y":[0.47998,0.33671,0.21222,0.26475,0.32296,0.40828,0.3651],"type":"scatter"}],                        {"height":650,"hovermode":"closest","margin":{"b":50,"pad":5,"t":50},"showlegend":true,"template":{"data":{"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"choropleth":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"choropleth"}],"contourcarpet":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"contourcarpet"}],"contour":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"contour"}],"heatmapgl":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"heatmapgl"}],"heatmap":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"heatmap"}],"histogram2dcontour":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"histogram2dcontour"}],"histogram2d":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"histogram2d"}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"mesh3d":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"mesh3d"}],"parcoords":[{"line":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"parcoords"}],"pie":[{"automargin":true,"type":"pie"}],"scatter3d":[{"line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatter3d"}],"scattercarpet":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattercarpet"}],"scattergeo":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattergeo"}],"scattergl":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattergl"}],"scattermapbox":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattermapbox"}],"scatterpolargl":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterpolargl"}],"scatterpolar":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterpolar"}],"scatter":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatter"}],"scatterternary":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterternary"}],"surface":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"surface"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}]},"layout":{"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"autotypenumbers":"strict","coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]],"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]},"colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"geo":{"bgcolor":"white","lakecolor":"white","landcolor":"#E5ECF6","showlakes":true,"showland":true,"subunitcolor":"white"},"hoverlabel":{"align":"left"},"hovermode":"closest","mapbox":{"style":"light"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"bgcolor":"#E5ECF6","radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"ternary":{"aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"bgcolor":"#E5ECF6","caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"title":{"x":0.05},"xaxis":{"automargin":true,"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","zerolinewidth":2},"yaxis":{"automargin":true,"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","zerolinewidth":2}}},"title":{"text":"Happiness vs Generosity vs Economy"},"xaxis":{"autorange":false,"range":[1.9872999999999998,10.621799999999999],"title":{"text":"Happiness Score"}},"yaxis":{"autorange":false,"range":[0.0,1.114232],"title":{"text":"Generosity"}}},                        {"scrollzoom": true, "responsive": true}                    ).then(function(){

var gd = document.getElementById('ca99ba77-4e96-4de0-a562-1e4841089623');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>


##### Bullet Chart to Represent the Range for some of the most Important Attributes given in the data. We have taken Happiness, Economy, Freedom, and Family. for analysis of their range.

If the values for the given attributes lie in the Dark Blue Region then it is in the critical region.

If the values for the given attributes lie in the light blue region then is is in good condition.

If the values for the given attributes lie above or near the diamond then is in the best state or condition.

White Regions are depicting the Maxima that could be achieved.


```python
import plotly.figure_factory as ff

data = (
  {"label": "Happiness", "sublabel":"score",
   "range": [5, 6, 8], "performance": [5.5, 6.5], "point": [7]},
  {"label": "Economy", "sublabel": "score", "range": [0, 1, 2],
   "performance": [1, 1.5], "sublabel":"score","point": [1.5]},
  {"label": "Family","sublabel":"score", "range": [0, 1, 2],
   "performance": [1, 1.5],"sublabel":"score", "point": [1.3]},
  {"label": "Freedom","sublabel":"score", "range": [0, 0.3, 0.6],
   "performance": [0.3, 0.4],"sublabel":"score", "point": [0.5]},
  {"label": "Trust", "sublabel":"score","range": [0, 0.2, 0.5],
   "performance": [0.3, 0.4], "point": [0.4]}
)

fig = ff.create_bullet(
    data, titles='label', subtitles='sublabel', markers='point',
    measures='performance', ranges='range', orientation='v',
)
py.iplot(fig, filename='bullet chart from dict')
```


<div>                            <div id="e68d68bf-d0d5-4436-bcba-a97f5735fc83" class="plotly-graph-div" style="height:600px; width:1000px;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("e68d68bf-d0d5-4436-bcba-a97f5735fc83")) {                    Plotly.newPlot(                        "e68d68bf-d0d5-4436-bcba-a97f5735fc83",                        [{"base":0,"hoverinfo":"y","marker":{"color":"rgb(245.0, 245.0, 245.0)"},"name":"ranges","orientation":"v","width":2,"x":[0],"xaxis":"x","y":[8],"yaxis":"y","type":"bar"},{"base":0,"hoverinfo":"y","marker":{"color":"rgb(222.5, 222.5, 222.5)"},"name":"ranges","orientation":"v","width":2,"x":[0],"xaxis":"x","y":[6],"yaxis":"y","type":"bar"},{"base":0,"hoverinfo":"y","marker":{"color":"rgb(200.0, 200.0, 200.0)"},"name":"ranges","orientation":"v","width":2,"x":[0],"xaxis":"x","y":[5],"yaxis":"y","type":"bar"},{"base":0,"hoverinfo":"y","marker":{"color":"rgb(176.0, 196.0, 221.0)"},"name":"measures","orientation":"v","width":0.4,"x":[0.5],"xaxis":"x","y":[6.5],"yaxis":"y","type":"bar"},{"base":0,"hoverinfo":"y","marker":{"color":"rgb(31.0, 119.0, 180.0)"},"name":"measures","orientation":"v","width":0.4,"x":[0.5],"xaxis":"x","y":[5.5],"yaxis":"y","type":"bar"},{"hoverinfo":"y","marker":{"color":"rgb(0, 0, 0)","size":12,"symbol":"diamond-tall"},"name":"markers","x":[0.5],"xaxis":"x","y":[7],"yaxis":"y","type":"scatter"},{"base":0,"hoverinfo":"y","marker":{"color":"rgb(245.0, 245.0, 245.0)"},"name":"ranges","orientation":"v","width":2,"x":[0],"xaxis":"x2","y":[2],"yaxis":"y2","type":"bar"},{"base":0,"hoverinfo":"y","marker":{"color":"rgb(222.5, 222.5, 222.5)"},"name":"ranges","orientation":"v","width":2,"x":[0],"xaxis":"x2","y":[1],"yaxis":"y2","type":"bar"},{"base":0,"hoverinfo":"y","marker":{"color":"rgb(200.0, 200.0, 200.0)"},"name":"ranges","orientation":"v","width":2,"x":[0],"xaxis":"x2","y":[0],"yaxis":"y2","type":"bar"},{"base":0,"hoverinfo":"y","marker":{"color":"rgb(176.0, 196.0, 221.0)"},"name":"measures","orientation":"v","width":0.4,"x":[0.5],"xaxis":"x2","y":[1.5],"yaxis":"y2","type":"bar"},{"base":0,"hoverinfo":"y","marker":{"color":"rgb(31.0, 119.0, 180.0)"},"name":"measures","orientation":"v","width":0.4,"x":[0.5],"xaxis":"x2","y":[1],"yaxis":"y2","type":"bar"},{"hoverinfo":"y","marker":{"color":"rgb(0, 0, 0)","size":12,"symbol":"diamond-tall"},"name":"markers","x":[0.5],"xaxis":"x2","y":[1.5],"yaxis":"y2","type":"scatter"},{"base":0,"hoverinfo":"y","marker":{"color":"rgb(245.0, 245.0, 245.0)"},"name":"ranges","orientation":"v","width":2,"x":[0],"xaxis":"x3","y":[2],"yaxis":"y3","type":"bar"},{"base":0,"hoverinfo":"y","marker":{"color":"rgb(222.5, 222.5, 222.5)"},"name":"ranges","orientation":"v","width":2,"x":[0],"xaxis":"x3","y":[1],"yaxis":"y3","type":"bar"},{"base":0,"hoverinfo":"y","marker":{"color":"rgb(200.0, 200.0, 200.0)"},"name":"ranges","orientation":"v","width":2,"x":[0],"xaxis":"x3","y":[0],"yaxis":"y3","type":"bar"},{"base":0,"hoverinfo":"y","marker":{"color":"rgb(176.0, 196.0, 221.0)"},"name":"measures","orientation":"v","width":0.4,"x":[0.5],"xaxis":"x3","y":[1.5],"yaxis":"y3","type":"bar"},{"base":0,"hoverinfo":"y","marker":{"color":"rgb(31.0, 119.0, 180.0)"},"name":"measures","orientation":"v","width":0.4,"x":[0.5],"xaxis":"x3","y":[1],"yaxis":"y3","type":"bar"},{"hoverinfo":"y","marker":{"color":"rgb(0, 0, 0)","size":12,"symbol":"diamond-tall"},"name":"markers","x":[0.5],"xaxis":"x3","y":[1.3],"yaxis":"y3","type":"scatter"},{"base":0,"hoverinfo":"y","marker":{"color":"rgb(245.0, 245.0, 245.0)"},"name":"ranges","orientation":"v","width":2,"x":[0],"xaxis":"x4","y":[0.6],"yaxis":"y4","type":"bar"},{"base":0,"hoverinfo":"y","marker":{"color":"rgb(222.5, 222.5, 222.5)"},"name":"ranges","orientation":"v","width":2,"x":[0],"xaxis":"x4","y":[0.3],"yaxis":"y4","type":"bar"},{"base":0,"hoverinfo":"y","marker":{"color":"rgb(200.0, 200.0, 200.0)"},"name":"ranges","orientation":"v","width":2,"x":[0],"xaxis":"x4","y":[0],"yaxis":"y4","type":"bar"},{"base":0,"hoverinfo":"y","marker":{"color":"rgb(176.0, 196.0, 221.0)"},"name":"measures","orientation":"v","width":0.4,"x":[0.5],"xaxis":"x4","y":[0.4],"yaxis":"y4","type":"bar"},{"base":0,"hoverinfo":"y","marker":{"color":"rgb(31.0, 119.0, 180.0)"},"name":"measures","orientation":"v","width":0.4,"x":[0.5],"xaxis":"x4","y":[0.3],"yaxis":"y4","type":"bar"},{"hoverinfo":"y","marker":{"color":"rgb(0, 0, 0)","size":12,"symbol":"diamond-tall"},"name":"markers","x":[0.5],"xaxis":"x4","y":[0.5],"yaxis":"y4","type":"scatter"},{"base":0,"hoverinfo":"y","marker":{"color":"rgb(245.0, 245.0, 245.0)"},"name":"ranges","orientation":"v","width":2,"x":[0],"xaxis":"x5","y":[0.5],"yaxis":"y5","type":"bar"},{"base":0,"hoverinfo":"y","marker":{"color":"rgb(222.5, 222.5, 222.5)"},"name":"ranges","orientation":"v","width":2,"x":[0],"xaxis":"x5","y":[0.2],"yaxis":"y5","type":"bar"},{"base":0,"hoverinfo":"y","marker":{"color":"rgb(200.0, 200.0, 200.0)"},"name":"ranges","orientation":"v","width":2,"x":[0],"xaxis":"x5","y":[0],"yaxis":"y5","type":"bar"},{"base":0,"hoverinfo":"y","marker":{"color":"rgb(176.0, 196.0, 221.0)"},"name":"measures","orientation":"v","width":0.4,"x":[0.5],"xaxis":"x5","y":[0.4],"yaxis":"y5","type":"bar"},{"base":0,"hoverinfo":"y","marker":{"color":"rgb(31.0, 119.0, 180.0)"},"name":"measures","orientation":"v","width":0.4,"x":[0.5],"xaxis":"x5","y":[0.3],"yaxis":"y5","type":"bar"},{"hoverinfo":"y","marker":{"color":"rgb(0, 0, 0)","size":12,"symbol":"diamond-tall"},"name":"markers","x":[0.5],"xaxis":"x5","y":[0.4],"yaxis":"y5","type":"scatter"}],                        {"annotations":[{"font":{"color":"#0f0f0f","size":13},"showarrow":false,"text":"<b>Happiness</b>","textangle":0,"x":0.019999999999999997,"xanchor":"center","xref":"paper","y":1.03,"yanchor":"middle","yref":"paper"},{"font":{"color":"#0f0f0f","size":13},"showarrow":false,"text":"<b>Economy</b>","textangle":0,"x":0.26,"xanchor":"center","xref":"paper","y":1.03,"yanchor":"middle","yref":"paper"},{"font":{"color":"#0f0f0f","size":13},"showarrow":false,"text":"<b>Family</b>","textangle":0,"x":0.5,"xanchor":"center","xref":"paper","y":1.03,"yanchor":"middle","yref":"paper"},{"font":{"color":"#0f0f0f","size":13},"showarrow":false,"text":"<b>Freedom</b>","textangle":0,"x":0.74,"xanchor":"center","xref":"paper","y":1.03,"yanchor":"middle","yref":"paper"},{"font":{"color":"#0f0f0f","size":13},"showarrow":false,"text":"<b>Trust</b>","textangle":0,"x":0.98,"xanchor":"center","xref":"paper","y":1.03,"yanchor":"middle","yref":"paper"}],"barmode":"stack","height":600,"margin":{"l":80},"showlegend":false,"template":{"data":{"barpolar":[{"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"#E5ECF6","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"white","linecolor":"white","minorgridcolor":"white","startlinecolor":"#2a3f5f"},"type":"carpet"}],"choropleth":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"choropleth"}],"contourcarpet":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"contourcarpet"}],"contour":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"contour"}],"heatmapgl":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"heatmapgl"}],"heatmap":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"heatmap"}],"histogram2dcontour":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"histogram2dcontour"}],"histogram2d":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"histogram2d"}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"mesh3d":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"mesh3d"}],"parcoords":[{"line":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"parcoords"}],"pie":[{"automargin":true,"type":"pie"}],"scatter3d":[{"line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatter3d"}],"scattercarpet":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattercarpet"}],"scattergeo":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattergeo"}],"scattergl":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattergl"}],"scattermapbox":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattermapbox"}],"scatterpolargl":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterpolargl"}],"scatterpolar":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterpolar"}],"scatter":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatter"}],"scatterternary":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterternary"}],"surface":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"surface"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}]},"layout":{"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"autotypenumbers":"strict","coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]],"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]},"colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"geo":{"bgcolor":"white","lakecolor":"white","landcolor":"#E5ECF6","showlakes":true,"showland":true,"subunitcolor":"white"},"hoverlabel":{"align":"left"},"hovermode":"closest","mapbox":{"style":"light"},"paper_bgcolor":"white","plot_bgcolor":"#E5ECF6","polar":{"angularaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"bgcolor":"#E5ECF6","radialaxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"scene":{"xaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"},"yaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"},"zaxis":{"backgroundcolor":"#E5ECF6","gridcolor":"white","gridwidth":2,"linecolor":"white","showbackground":true,"ticks":"","zerolinecolor":"white"}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"ternary":{"aaxis":{"gridcolor":"white","linecolor":"white","ticks":""},"baxis":{"gridcolor":"white","linecolor":"white","ticks":""},"bgcolor":"#E5ECF6","caxis":{"gridcolor":"white","linecolor":"white","ticks":""}},"title":{"x":0.05},"xaxis":{"automargin":true,"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","zerolinewidth":2},"yaxis":{"automargin":true,"gridcolor":"white","linecolor":"white","ticks":"","title":{"standoff":15},"zerolinecolor":"white","zerolinewidth":2}}},"title":{"text":"Bullet Chart"},"width":1000,"xaxis":{"anchor":"y","domain":[0.0,0.039999999999999994],"range":[0,1],"showgrid":false,"showticklabels":false,"zeroline":false},"yaxis":{"anchor":"x","domain":[0.0,1.0],"showgrid":false,"tickwidth":1,"zeroline":false},"xaxis2":{"anchor":"y2","domain":[0.24,0.27999999999999997],"range":[0,1],"showgrid":false,"showticklabels":false,"zeroline":false},"yaxis2":{"anchor":"x2","domain":[0.0,1.0],"showgrid":false,"tickwidth":1,"zeroline":false},"xaxis3":{"anchor":"y3","domain":[0.48,0.52],"range":[0,1],"showgrid":false,"showticklabels":false,"zeroline":false},"yaxis3":{"anchor":"x3","domain":[0.0,1.0],"showgrid":false,"tickwidth":1,"zeroline":false},"xaxis4":{"anchor":"y4","domain":[0.7200000000000001,0.7600000000000001],"range":[0,1],"showgrid":false,"showticklabels":false,"zeroline":false},"yaxis4":{"anchor":"x4","domain":[0.0,1.0],"showgrid":false,"tickwidth":1,"zeroline":false},"xaxis5":{"anchor":"y5","domain":[0.96,1.0],"range":[0,1],"showgrid":false,"showticklabels":false,"zeroline":false},"yaxis5":{"anchor":"x5","domain":[0.0,1.0],"showgrid":false,"tickwidth":1,"zeroline":false}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('e68d68bf-d0d5-4436-bcba-a97f5735fc83');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>


##### Bullet Chart to Represent the Range for some of the most Important Attributes given in the data. We have taken Happiness, Economy, Freedom, and Family. for analysis of their range.

If the values for the given attributes lie in the Dark Blue Region then it is in the critical region.

If the values for the given attributes lie in the light blue region then is is in good condition.

If the values for the given attributes lie above or near the diamond then is in the best state or condition.

White Regions are depicting the Maxima that could be achieved.


```python
df12 = data_df['Region'].value_counts()

label_df12 = df12.index
size_df12 = df12.values


colors = ['aqua', 'gold', 'yellow', 'crimson', 'magenta']

trace = go.Pie(
         labels = label_df12, values = size_df12, marker = dict(colors = colors), name = '12', hole = 0.3)

data = [trace]

layout1 = go.Layout(
           title = 'Regions')

fig = go.Figure(data = data, layout = layout1)
py.iplot(fig)
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-46-3ddcf198969a> in <module>
    ----> 1 df12 = data_df['Region'].value_counts()
          2 
          3 label_df12 = df12.index
          4 size_df12 = df12.values
          5 
    

    NameError: name 'data_df' is not defined



```python

```


```python

```
